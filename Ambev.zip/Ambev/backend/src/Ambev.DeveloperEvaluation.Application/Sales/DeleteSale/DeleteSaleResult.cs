namespace Ambev.DeveloperEvaluation.Application.Sales.DeleteSale;

public class DeleteSaleResult
{
    public bool Success { get; set; }
}
