namespace Ambev.DeveloperEvaluation.Domain.Enums;

public enum SaleStatus
{
    Unknown = 0,
    Active = 1,
    Cancelled = 2
}
